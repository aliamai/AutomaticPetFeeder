import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { UserintPageRoutingModule } from './userint-routing.module';

import { UserintPage } from './userint.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    UserintPageRoutingModule
  ],
  declarations: [UserintPage]
})
export class UserintPageModule {}
