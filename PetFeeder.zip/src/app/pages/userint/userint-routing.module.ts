import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UserintPage } from './userint.page';

const routes: Routes = [
  {
    path: '',
    component: UserintPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UserintPageRoutingModule {}
