import { TicketService } from './../../services/ticket.service';
import { AuthService } from './../../services/auth.service';
import { Component, OnInit } from '@angular/core';
import { AlertController, ModalController, NavController } from '@ionic/angular';

@Component({
  selector: 'app-userint',
  templateUrl: './userint.page.html',
  styleUrls: ['./userint.page.scss'],
})
export class UserintPage implements OnInit {
  timelist
  userid
  timeval = []
  formattedtimeval = []
  toggleval = []
  showpicker = []

  infolist
  foodweight:number
  videosource='http://172.20.10.3/mjpeg/1'
  iframe
  constructor(public modalController: ModalController, private navCtrl: NavController, public alertController: AlertController, private auth: AuthService, private ticket: TicketService) { }

  ngOnInit() {
    this.iframe = <HTMLImageElement>document.getElementById('cameraid');
    this.iframe.setAttribute('src',this.videosource );

    this.timelist = this.ticket.getcollectionnoid('timelist')
    this.timelist.subscribe((a) => {
      a.map((element, index) => {
        this.showpicker[index] = false
        // let newtime = +element.time
        this.toggleval[index] = element.toggle
        let hour= element.hour;
        let minutes=element.minutes
        let timeall = new Date()
        timeall.setHours(hour)
        timeall.setMinutes(minutes)
        timeall.setSeconds(0)
        timeall.setMilliseconds(0)

        // this.timeval[index]=timeall.toISOString()
    
        this.timeval[index] = new Date(new Date(timeall).getTime()-new Date(timeall).getTimezoneOffset()*60000).toISOString()

        // this.timeval[index] = new Date(new Date(newtime).getTime()-new Date(newtime).getTimezoneOffset()*60000).toISOString()
        // this.formattedtimeval[index] = new Date(new Date(this.timeval[index]).getTime()+ new Date(this.timeval[index]).getTimezoneOffset()*60000).toLocaleTimeString()
        this.formattedtimeval[index] = new Date(new Date(this.timeval[index]).getTime()+ new Date(this.timeval[index]).getTimezoneOffset()*60000).toLocaleTimeString()

        console.log(this.timeval[index],  this.formattedtimeval[index])
      });
    })
    this.infolist=this.ticket.getcollectionnoid('infolist')
  }
  updatefood(item){
    this.videosource=item.videosource
    item.foodweight=+item.foodweight
this.ticket.updatebyid(item.id,item,'infolist')
  }
  timeconvert(time) {
    let newtime = new Date(time)
    return newtime
  }
  updatetimeval(time, index) {
    let timevar= new Date(this.timeval[index])
    timevar.setSeconds(0)
    timevar.setMilliseconds(0)

let timenooffset:number=new Date(timevar).getTime()
// let timeoffset:number=new Date(this.timeval[index]).getTimezoneOffset()*60000
// let timewithoffset=timenooffset+timeoffset
    this.ticket.updatebyid(time.id, { time: timenooffset,toggle:this.toggleval[index] ,hour:new Date(timenooffset).getHours(),minutes:new Date(timenooffset).getMinutes()}, 'timelist')
    console.log(timenooffset)
  }
  signOut() {
    this.auth.signOut();
  }
  doRefresh(event) {
    console.log('Begin async operation');

    setTimeout(() => {
      console.log('Async operation has ended');
     
      this.iframe.src = this.iframe.src;
      event.target.complete();
    }, 2000);
  }

}
