import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { HfPageRoutingModule } from './hf-routing.module';

import { HfPage } from './hf.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HfPageRoutingModule
  ],
  declarations: [HfPage]
})
export class HfPageModule {}
