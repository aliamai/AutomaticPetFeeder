import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hf',
  templateUrl: './hf.page.html',
  styleUrls: ['./hf.page.scss'],
})
export class HfPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
