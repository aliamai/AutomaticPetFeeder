import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { WcPageRoutingModule } from './wc-routing.module';

import { WcPage } from './wc.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    WcPageRoutingModule
  ],
  declarations: [WcPage]
})
export class WcPageModule {}
