import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wc',
  templateUrl: './wc.page.html',
  styleUrls: ['./wc.page.scss'],
})
export class WcPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
