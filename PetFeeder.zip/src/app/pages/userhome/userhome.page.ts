import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-userhome',
  templateUrl: './userhome.page.html',
  styleUrls: ['./userhome.page.scss'],
})
export class UserhomePage implements OnInit {
  constructor() { }

  ngOnInit() {
  }

}
