import { Component, OnInit } from '@angular/core';
import { ToastController, LoadingController } from '@ionic/angular';
import { Router } from '@angular/router';
import { AngularFireAuth } from '@angular/fire/compat/auth';

@Component({
  selector: 'app-resetpass',
  templateUrl: './resetpass.page.html',
  styleUrls: ['./resetpass.page.scss'],
})
export class ResetpassPage implements OnInit {

  email: string;

  constructor(
    private afauth: AngularFireAuth,
    private toastCtrl: ToastController,
    private loadingCtrl: LoadingController,
    private router: Router
  ) { }

  ngOnInit() {
  }

  async resetPass()
  {
    if(this.email)
    {
    const loading = await this.loadingCtrl.create({
      message: 'Please Wait..',
      spinner: 'crescent',
      showBackdrop: true
    });
    loading.present();

    this.afauth.sendPasswordResetEmail(this.email)
    .then(()=> {
      loading.dismiss();
      this.toast('Please Check Your Email!', 'success');
      this.router.navigate(['/login']);
    })
    .catch((error)=> {
      loading.dismiss();
      this.toast(error.message, 'danger');
    })

  } else{
    this.toast('Please Enter Your Email Address!','danger');
  }
}

 async toast(message, status)
 {
  const toast = await this.toastCtrl.create({
    message: message,
    position: 'top',
    color: status,
    duration: 2000
  });

  toast.present();
 }
}