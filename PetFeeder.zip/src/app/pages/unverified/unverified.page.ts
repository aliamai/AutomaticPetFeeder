import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unverified',
  templateUrl: './unverified.page.html',
  styleUrls: ['./unverified.page.scss'],
})
export class UnverifiedPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
