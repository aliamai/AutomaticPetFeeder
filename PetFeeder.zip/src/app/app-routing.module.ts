import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then(m => m.HomePageModule)
  },
  {
    path: 'register',
    loadChildren: () => import('./pages/register/register.module').then(m => m.RegisterPageModule)
  },
  { path: 'login', loadChildren: () => import('./pages/login/login.module').then(m => m.LoginPageModule) },
  {
    path: 'user',
    loadChildren: () => import('./pages/userhome/userhome.module').then(m => m.UserhomePageModule),
    canActivate: [AuthGuard],
    data: {
      role: 'USER'
    }
  },
  {
    path: 'admin',
    loadChildren: () => import('./pages/adminhome/adminhome.module').then(m => m.AdminhomePageModule),
    canActivate: [AuthGuard],
    data: {
      role: 'ADMIN'
    }
  },
  {
    path: 'unverified',
    loadChildren: () => import('./pages/unverified/unverified.module').then(m => m.UnverifiedPageModule),

    // loadChildren:'./pages/unverified/unverified.module#UnverifiedPageModule',
    canActivate: [AuthGuard],
    data: {
      role: 'unverified'
    }
  },
  { path: '', redirectTo: 'user', pathMatch: 'full' },
  {
    path: 'logout',
    loadChildren: () => import('./pages/logout/logout.module').then( m => m.LogoutPageModule)
  },
  {
    path: 'userint',
    loadChildren: () => import('./pages/userint/userint.module').then( m => m.UserintPageModule)
  },
  {
    path: 'resetpass',
    loadChildren: () => import('./pages/resetpass/resetpass.module').then( m => m.ResetpassPageModule)
  },
  {
    path: 'how',
    loadChildren: () => import('./pages/how/how.module').then( m => m.HowPageModule)
  },
  {
    path: 'wc',
    loadChildren: () => import('./pages/wc/wc.module').then( m => m.WcPageModule)
  },
  {
    path: 'usermanual',
    loadChildren: () => import('./pages/usermanual/usermanual.module').then( m => m.UsermanualPageModule)
  },
  {
    path: 'hf',
    loadChildren: () => import('./pages/hf/hf.module').then( m => m.HfPageModule)
  },
  {
    path: 'about',
    loadChildren: () => import('./pages/about/about.module').then( m => m.AboutPageModule)
  },
  // {
  //   path: 'login',
  //   loadChildren: () => import('./pages/login/login.module').then( m => m.LoginPageModule)
  // },
  // {
  //   path: 'register',
  //   loadChildren: () => import('./pages/register/register.module').then( m => m.RegisterPageModule)
  // },
  // {
  //   path: 'userhome',
  //   loadChildren: () => import('./pages/userhome/userhome.module').then( m => m.UserhomePageModule)
  // },
  // {
  //   path: 'adminhome',
  //   loadChildren: () => import('./pages/adminhome/adminhome.module').then( m => m.AdminhomePageModule)
  // },
  // {
  //   path: 'unverified',
  //   loadChildren: () => import('./pages/unverified/unverified.module').then( m => m.UnverifiedPageModule)
  // }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
